CREATE DATABASE flappy_bird;
USE flappy_bird;

CREATE TABLE scores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    player_name VARCHAR(50),
    score INT,
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
