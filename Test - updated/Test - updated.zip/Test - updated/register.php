<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'flappybird');

// Check for connection error
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Check if POST data is received
if (!isset($_POST['username']) || !isset($_POST['password'])) {
    die(json_encode(["success" => false, "error" => "Username or password not set."]));
}

$username = $_POST['username'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

// Prepare the SQL query
$stmt = $conn->prepare("INSERT INTO users (username, password, highscore) VALUES (?, ?, 0)");
$stmt->bind_param("ss", $username, $password);

if ($stmt->execute()) {
    echo json_encode(["success" => true, "message" => "User registered successfully."]);
} else {
    if ($conn->errno === 1062) { // Duplicate entry error
        echo json_encode(["success" => false, "error" => "Username already exists."]);
    } else {
        echo json_encode(["success" => false, "error" => "SQL execution error: " . $stmt->error]);
    }
}

$stmt->close();
$conn->close();
?>
