<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'flappybird');

// Check for connection error
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// Check if POST data is received
if (!isset($_POST['username']) || !isset($_POST['password'])) {
    die(json_encode(["success" => false, "error" => "Username or password not set."]));
}

$username = $_POST['username'];
$password = $_POST['password'];

// Prepare the SQL query
$stmt = $conn->prepare("SELECT id, password, highscore FROM users WHERE username = ?");
$stmt->bind_param("s", $username);

if ($stmt->execute()) {
    $result = $stmt->get_result();
    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            echo json_encode(["success" => true, "username" => $username, "highscore" => $row['highscore']]);
        } else {
            echo json_encode(["success" => false, "error" => "Incorrect password."]);
        }
    } else {
        echo json_encode(["success" => false, "error" => "User not found."]);
    }
} else {
    echo json_encode(["success" => false, "error" => "SQL execution error: " . $stmt->error]);
}

$stmt->close();
$conn->close();
?>
